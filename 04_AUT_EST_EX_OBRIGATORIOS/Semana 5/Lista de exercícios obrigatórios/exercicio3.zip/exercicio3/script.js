// MEU ALGORITMO:
function ordenado(lista){
    for (var i = 0; i < lista.length; i++){
        for (var j = 0; j < lista.length; j++){
            if (lista[j] > lista[j+1]){
                var auxiliar = lista[i]
                lista[i] = lista[i+1]
                lista[i+1] = auxiliar
            }
        }
    }
    return lista
}

function ordenar(){
    var lista = document.getElementById("lista").value;
    console.log(lista)
    lista = lista.split(',');
    var ordenaLista = lista.map(Number)
    console.log(ordenaLista)
    ordenado(ordenaLista);
    document.getElementById("listaOrdenada").textContent = ordenaLista
}



//SOLUÇÃO INTERNET:
// function ordenar(){
//     var lista = document.getElementById("lista").value;
//     lista = lista.split(',');
//     lista = lista.map(Number)
//     len = lista.length
//     var para = false;
//     do{
//         for(var i = 0; i < len; i++){
//             for(var j = 0; j < len; i++){
//                 if(lista[j] > lista[j+1]){
//                     var auxiliar = array[j];
//                     lista[j] = lista[j+1];
//                     lista[j+1] = auxiliar;
//                     para = true
//                 }
//             }
//         }
//     } while (para)
//     return lista;
// }

// SOLUÇÃO INTERNET 2:

